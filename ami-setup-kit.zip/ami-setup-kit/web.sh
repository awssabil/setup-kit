#!/bin/bash

region=$1

echo "$(tput setaf 1)Running Web AMI Software Installation Script$(tput sgr 0)"

sudo apt-get update -y
sudo apt-get install autoconf gcc curl libmcrypt-dev make libssl-dev wget dc vim net-tools build-essential gettext unzip python3-pip python-dev build-essential -y
cat <<EOF | sudo tee /etc/apt/source.list
deb http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-backports main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb-src http://ports.ubuntu.com/ubuntu-ports focal-security main restricted universe multiverse
deb http://archive.canonical.com/ubuntu focal partner
deb-src http://archive.canonical.com/ubuntu focal partner
EOF

sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ focal-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
sudo apt-get install --reinstall ubuntu-advantage-tools -y
sudo apt-get update -y
sudo apt-get install autoconf gcc curl libmcrypt-dev make libssl-dev wget dc vim net-tools build-essential gettext -y
sudo apt-get install nfs-common python3 -y
sudo update-alternatives --install  /usr/bin/python python /usr/bin/python3 1000

sudo apt-get install -y unzip python3-pip python-dev build-essential

#nrpe agent installation

sudo useradd nagios

curl -L -O https://nagios-plugins.org/download/nagios-plugins-2.2.1.tar.gz
tar zxf nagios-plugins-2.2.1.tar.gz
cd nagios-plugins-2.2.1
wget -O config.guess 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.guess;hb=HEAD'
wget -O config.sub 'http://git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.sub;hb=HEAD'
sudo cp config.guess build-aux/
sudo cp config.sub build-aux/
sudo ./configure --build=aarch64-linux
make
sudo make install

cd /home/ubuntu/
sudo rm nagios-plugins-2.2.1.tar.gz
sudo rm -rf nagios-plugins-2.2.1

sudo curl -L -O https://github.com/NagiosEnterprises/nrpe/releases/download/nrpe-3.2.1/nrpe-3.2.1.tar.gz
sudo tar zxf nrpe-3.2.1.tar.gz
cd nrpe-3.2.1
sudo ./configure --enable-command-args --with-ssl=/usr/include/openssl --with-ssl-lib=/usr/lib/aarch64-linux-gnu --enable-ssl
sudo make all
sudo make install-daemon
sudo make install-config
sudo make install-init
sudo systemctl start nrpe
sudo systemctl enable nrpe
cd ~
sudo rm nrpe-3.2.1.tar.gz
sudo rm -rf nrpe-3.2.1

(crontab -l; echo "0 */4 * * * bash /home/ubuntu/dropcache.sh") | sort -u | crontab -

cd /home/ubuntu/ami-setup-kit

sudo cp ./scripts/dropcache.sh /home/ubuntu/
sudo chmod +x /home/ubuntu/dropcache.sh

sudo cp ./nrpe-config/plugins/mem_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/ram_chk /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/check_cpu.sh /usr/local/nagios/libexec/
sudo cp ./nrpe-config/plugins/check_mem.pl /usr/local/nagios/libexec/
sudo chmod +x /usr/local/nagios/libexec/mem_chk
sudo chmod +x /usr/local/nagios/libexec/ram_chk
sudo chmod +x /usr/local/nagios/libexec/check_cpu.sh
sudo chmod +x /usr/local/nagios/libexec/check_mem.pl

sudo cp ./nrpe-config/nrpe.cfg /usr/local/nagios/etc/nrpe.cfg

sudo service nrpe stop
sudo service nrpe start
sudo systemctl enable nrpe


sudo apt-get install nginx -y

#sudo curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
#sudo unzip awscliv2.zip
#sudo ./aws/install

sudo apt update -y
sudo apt install python3 python3-pip
sudo pip3 install awscli
aws --version

sudo apt-get update -y
sudo apt-get install ruby-full -y
sudo apt-get install wget -y
wget https://aws-codedeploy-${region}.s3.${region}.amazonaws.com/latest/install
chmod +x ./install
sudo ./install auto > /tmp/logfile
echo "Codedeploy-Agent Status:"
sudo service codedeploy-agent status


cd /home/ubuntu/ami-setup-kit


sudo cp ./nginx-config/web /etc/nginx/sites-available/web

if test -f "/etc/nginx/sites-enabled/default"; then
	sudo rm /etc/nginx/sites-enabled/default
	sudo rm /etc/nginx/sites-available/default
fi



sudo ln -sf /etc/nginx/sites-available/web  /etc/nginx/sites-enabled/web

echo `ls -l /etc/nginx/sites-enabled`

cd /home/ubuntu/

mkdir /home/ubuntu/nginx-ssl

sudo rm -f /etc/nginx/nginx.conf
sudo cp ami-setup-kit/nginx-config/nginx.conf /etc/nginx/

sudo rm ami-setup-kit.zip
sudo rm -rf ami-setup-kit awscliv2.zip awscliv2 aws
