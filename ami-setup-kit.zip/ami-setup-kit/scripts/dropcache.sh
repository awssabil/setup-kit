#!/bin/bash

#It will check free memory on server if it is less than 30% script will execute and drop cache. 

mem=$(free | grep Mem | awk '{print $4/$2 * 100.0}'| cut -d "." -f 1 | cut -d "," -f 1)

if [[ $mem -lt 30 ]]
then
 
 sync; echo 3 | sudo tee /proc/sys/vm/drop_caches
 sync; echo 2 | sudo tee /proc/sys/vm/drop_caches
 sync; echo 1 | sudo tee /proc/sys/vm/drop_caches

else
  echo "Free Memory is OK"
fi