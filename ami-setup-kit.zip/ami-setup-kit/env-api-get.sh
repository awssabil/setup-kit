#!/bin/bash

if [[ $1 == "" ]]
then
 echo "No region!!"
 exit 0
fi

if [[ $2 == "" ]]
then
 echo "No Deployment Environment specified!!"
 exit 0
fi

REGION=$1
ENV=$2
DATABASE_HOST=$3
ApiEnv="/home/ubuntu/efs-api/docker-shared-data/env"

echo "wait"
echo "export SAAS_ENV=$(aws secretsmanager get-secret-value --secret-id SAAS_ENV --query SecretString --output text --region ${REGION~~})" > $ApiEnv
echo "export GEM_HOME=$(aws secretsmanager get-secret-value --secret-id GEM_HOME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export HOSTED_REGION=$(aws secretsmanager get-secret-value --secret-id HOSTED_REGION --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export WEB_PROTOCOL=$(aws secretsmanager get-secret-value --secret-id WEB_PROTOCOL --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export WEB_HOST=$(aws secretsmanager get-secret-value --secret-id WEB_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export WEB_PORT=$(aws secretsmanager get-secret-value --secret-id WEB_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export API_PROTOCOL=$(aws secretsmanager get-secret-value --secret-id API_PROTOCOL --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export API_HOST=$(aws secretsmanager get-secret-value --secret-id API_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export NODE_API_HOST=$(aws secretsmanager get-secret-value --secret-id NODE_API_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export API_PORT=$(aws secretsmanager get-secret-value --secret-id API_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export NODE_API_PORT=$(aws secretsmanager get-secret-value --secret-id NODE_API_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export REPORT_API_PROTOCOL=$(aws secretsmanager get-secret-value --secret-id REPORT_API_PROTOCOL --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export REPORT_API_HOST=$(aws secretsmanager get-secret-value --secret-id REPORT_API_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export REPORT_API_PORT=$(aws secretsmanager get-secret-value --secret-id REPORT_API_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "wait"
echo "export CUSTOMERIO_SITE_ID=$(aws secretsmanager get-secret-value --secret-id CUSTOMERIO_SITE_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export CUSTOMERIO_API_KEY=$(aws secretsmanager get-secret-value --secret-id CUSTOMERIO_API_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export CENTRAL_API_AUTH_TOKEN=$(aws secretsmanager get-secret-value --secret-id CENTRAL_API_AUTH_TOKEN --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export RAILS_ENV=$(aws secretsmanager get-secret-value --secret-id RAILS_ENV --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export HOSTED_ZONE_ID=$(aws secretsmanager get-secret-value --secret-id HOSTED_ZONE_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export PROD_ROLE_ARN=$(aws secretsmanager get-secret-value --secret-id PROD_ROLE_ARN --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SECRET_TOKEN=$(aws secretsmanager get-secret-value --secret-id SECRET_TOKEN --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export DEVISE_PEPPER=$(aws secretsmanager get-secret-value --secret-id DEVISE_PEPPER --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export MP_ACC_REGION=$(aws secretsmanager get-secret-value --secret-id MP_ACC_REGION --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export MP_ROLE_ARN=$(aws secretsmanager get-secret-value --secret-id MP_ROLE_ARN --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SAAS_SUBSCRIPTION_ENABLE=$(aws secretsmanager get-secret-value --secret-id SAAS_SUBSCRIPTION_ENABLE --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export HONEYBADGER_ENV=$(aws secretsmanager get-secret-value --secret-id HONEYBADGER_ENV --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export HONEYBADGER_API_KEY=$(aws secretsmanager get-secret-value --secret-id HONEYBADGER_API_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "wait"
echo "export SCOUT_KEY=$(aws secretsmanager get-secret-value --secret-id SCOUT_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export BUGSNAG_API_KEY=$(aws secretsmanager get-secret-value --secret-id BUGSNAG_API_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SMTP_USER_NAME=$(aws secretsmanager get-secret-value --secret-id SMTP_USER_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SES_USERNAME=$(aws secretsmanager get-secret-value --secret-id SES_USERNAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SES_PASSWORD=$(aws secretsmanager get-secret-value --secret-id SES_PASSWORD --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SES_ADDRESS=$(aws secretsmanager get-secret-value --secret-id SES_ADDRESS --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AWS_ACCESS_KEY_ID=$(aws secretsmanager get-secret-value --secret-id AWS_ACCESS_KEY_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AWS_SECRET_ACCESS_KEY=$(aws secretsmanager get-secret-value --secret-id AWS_SECRET_ACCESS_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export STS_AWS_ACCESS_KEY_ID=$(aws secretsmanager get-secret-value --secret-id STS_AWS_ACCESS_KEY_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export STS_SECRET_ACCESS_KEY=$(aws secretsmanager get-secret-value --secret-id STS_SECRET_ACCESS_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AZURE_CLIENT_ID=$(aws secretsmanager get-secret-value --secret-id AZURE_CLIENT_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AZURE_TENANT_ID=$(aws secretsmanager get-secret-value --secret-id AZURE_TENANT_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AZURE_SECRET_KEY=$(aws secretsmanager get-secret-value --secret-id AZURE_SECRET_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AZURE_SUBSCRIPTION_ID=$(aws secretsmanager get-secret-value --secret-id AZURE_SUBSCRIPTION_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export LOG_BACKUP_BUCKET=$(aws secretsmanager get-secret-value --secret-id LOG_BACKUP_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
#echo "export SOLR_HOST=$(aws secretsmanager get-secret-value --secret-id SOLR_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SOLR_PORT=$(aws secretsmanager get-secret-value --secret-id SOLR_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export DATABASE_NAME=$(aws secretsmanager get-secret-value --secret-id DATABASE_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export DATABASE_USER=$(aws secretsmanager get-secret-value --secret-id DATABASE_USER --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "wait"
echo "export DATABASE_PASSWORD=$(aws secretsmanager get-secret-value --secret-id DATABASE_PASSWORD --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export DATABASE_HOST=$(aws secretsmanager get-secret-value --secret-id DATABASE_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export TEST_DATABASE_NAME=$(aws secretsmanager get-secret-value --secret-id TEST_DATABASE_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export TEST_DATABASE_USER=$(aws secretsmanager get-secret-value --secret-id TEST_DATABASE_USER --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export TEST_DATABASE_PASSWORD=$(aws secretsmanager get-secret-value --secret-id TEST_DATABASE_PASSWORD --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
#echo "export REDIS_HOST=$(aws secretsmanager get-secret-value --secret-id REDIS_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export REDIS_PORT=$(aws secretsmanager get-secret-value --secret-id REDIS_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export MONGODB_HOST=$(aws secretsmanager get-secret-value --secret-id MONGODB_HOST --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export MONGODB_PORT=$(aws secretsmanager get-secret-value --secret-id MONGODB_PORT --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export REDSHIFT_VPC_ID=$(aws secretsmanager get-secret-value --secret-id REDSHIFT_VPC_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "wait"
echo "export REDSHIFT_REGION_ID=$(aws secretsmanager get-secret-value --secret-id REDSHIFT_REGION_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export ATHENA_WORKGROUP=$(aws secretsmanager get-secret-value --secret-id ATHENA_WORKGROUP --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export ATHENA_DATABASE=$(aws secretsmanager get-secret-value --secret-id ATHENA_DATABASE --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export APP_REGION=$(aws secretsmanager get-secret-value --secret-id APP_REGION --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export RAW_REPORT_BUCKET=$(aws secretsmanager get-secret-value --secret-id RAW_REPORT_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export PARQUET_REPORT_BUCKET=$(aws secretsmanager get-secret-value --secret-id PARQUET_REPORT_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export GLUE_JOB_NAME=$(aws secretsmanager get-secret-value --secret-id GLUE_JOB_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export AZURE_GLUE_JOB_NAME=$(aws secretsmanager get-secret-value --secret-id AZURE_GLUE_JOB_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export S3_BUCKET_NAME=$(aws secretsmanager get-secret-value --secret-id S3_BUCKET_NAME --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export S3_BUCKET_REGION=$(aws secretsmanager get-secret-value --secret-id S3_BUCKET_REGION --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export RAW_METRIC_BUCKET=$(aws secretsmanager get-secret-value --secret-id RAW_METRIC_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export PARQUET_METRIC_BUCKET=$(aws secretsmanager get-secret-value --secret-id PARQUET_METRIC_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export GCP_API_KEY=$(aws secretsmanager get-secret-value --secret-id GCP_API_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export FIXER_ACCESS_KEY=$(aws secretsmanager get-secret-value --secret-id FIXER_ACCESS_KEY --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export GLOBAL_ADMIN_ORGANIZATION_IDENTIFIER=$(aws secretsmanager get-secret-value --secret-id GLOBAL_ADMIN_ORGANIZATION_IDENTIFIER --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export ROUTE53_ROLE_ARN=$(aws secretsmanager get-secret-value --secret-id ROUTE53_ROLE_ARN --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export ROUTE53_EXTERNAL_ID=$(aws secretsmanager get-secret-value --secret-id ROUTE53_EXTERNAL_ID --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export BILLING_CONFIG_CSV_BUCKET=$(aws secretsmanager get-secret-value --secret-id BILLING_CONFIG_CSV_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export INVITE_USER_CSV_BUCKET=$(aws secretsmanager get-secret-value --secret-id INVITE_USER_CSV_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "export SERVICE_GROUP_CSV_BUCKET=$(aws secretsmanager get-secret-value --secret-id SERVICE_GROUP_CSV_BUCKET --query SecretString --output text --region ${REGION~~})" >> $ApiEnv
echo "finish"